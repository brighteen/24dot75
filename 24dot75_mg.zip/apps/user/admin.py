from django.contrib import admin
# 현재 모델이 없다면 추후 필요 시 등록
