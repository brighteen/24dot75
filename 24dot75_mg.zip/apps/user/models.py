from django.db import models
# 필요한 모델이 있을 경우 추가 (현재는 기본 Django User 모델 사용)
